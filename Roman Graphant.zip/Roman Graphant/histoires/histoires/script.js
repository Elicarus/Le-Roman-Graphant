document.addEventListener( 'scroll', function () {
  let d = document.getElementById( 'endless' );
  let endless_text = d.getAttribute('text_to_add') 
  d.innerHTML = d.innerHTML + endless_text
});

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('a[href]').forEach(link => {
    link.addEventListener('click', async function (e) {
        e.preventDefault();
        const href = this.getAttribute('href');
        await window.pywebview.api.load_html(href);
        window.scrollTo(0, 0); 
    });
    });
});